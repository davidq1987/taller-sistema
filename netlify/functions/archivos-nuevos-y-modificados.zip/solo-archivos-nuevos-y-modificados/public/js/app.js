// ------------------------------------------------------------------
// Sistema de Taller - lógica de frontend (vanilla JS, sin frameworks)
// ------------------------------------------------------------------

const API = {
  machines: "/api/machines",
  orders: "/api/orders",
  quotes: "/api/quotes",
  settings: "/api/settings",
  messages: "/api/messages",
  auth: "/api/auth",
  capacitaciones: "/api/capacitaciones",
  incidentes: "/api/incidentes",
  accidentes: "/api/accidentes",
  procedimientos: "/api/procedimientos",
};

let state = {
  machines: [],
  orders: [],
  quotes: [],
  settings: null,
  messages: [],
  capacitaciones: [],
  incidentes: [],
  accidentes: [],
  procedimientos: [],
};

// ---------- utilidades ----------

function $(sel) { return document.querySelector(sel); }
function $all(sel) { return Array.from(document.querySelectorAll(sel)); }

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function daysBetween(a, b) {
  // a, b: "YYYY-MM-DD" -> diferencia en días (b - a)
  const da = new Date(a + "T00:00:00");
  const db = new Date(b + "T00:00:00");
  return Math.round((db - da) / 86400000);
}

function addDays(dateStr, days) {
  const d = new Date(dateStr + "T00:00:00");
  d.setDate(d.getDate() + Number(days));
  return d.toISOString().slice(0, 10);
}

function formatDate(dateStr) {
  if (!dateStr) return "-";
  const [y, m, d] = dateStr.split("-");
  return `${d}/${m}/${y}`;
}

function money(n) {
  const num = Number(n) || 0;
  return "$" + num.toLocaleString("es-AR", { maximumFractionDigits: 0 });
}

function slug(str) {
  return (str || "").toString().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\s+/g, "-");
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str == null ? "" : str;
  return d.innerHTML;
}

async function apiGet(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error("Error al leer datos");
  return res.json();
}

async function apiSend(url, method, body) {
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error("Error al guardar");
  return res.json();
}

async function apiDelete(url) {
  const res = await fetch(url, { method: "DELETE" });
  if (!res.ok && res.status !== 204) throw new Error("Error al borrar");
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ---------- navegación lateral ----------

const VIEW_META = {
  inicio: { title: "Inicio", sub: "Panorama general del taller" },
  mantenimiento: { title: "Mantenimiento", sub: "Mantenimiento preventivo de máquinas y equipos" },
  produccion: { title: "Órdenes de trabajo", sub: "Gestión operativa del taller, seguimiento por estado" },
  monitor: { title: "Monitor de taller", sub: "Pizarra en vivo de órdenes de trabajo activas" },
  presupuestos: { title: "Presupuestos", sub: "Cotización de trabajos para clientes" },
  hys: { title: "Higiene y Seguridad", sub: "Capacitaciones, incidentes, accidentes, procedimientos y KPI" },
  mensajes: { title: "Mensajes interno", sub: "Comunicación entre Gerencia y Mantenimiento" },
  config: { title: "Configuración", sub: "Datos de la empresa y tarifas" },
};

$all(".nav-item").forEach((btn) => {
  btn.addEventListener("click", () => {
    const view = btn.dataset.view;
    $all(".nav-item").forEach((b) => b.classList.remove("active"));
    $all(".view").forEach((v) => v.classList.remove("active"));
    btn.classList.add("active");
    $("#view-" + view).classList.add("active");
    const meta = VIEW_META[view] || { title: "", sub: "" };
    $("#viewTitle").textContent = meta.title;
    $("#viewSubtitle").textContent = meta.sub;

    stopMonitorRefresh();
    if (view === "monitor") {
      renderMonitor();
      startMonitorRefresh();
    }
    if (view === "mensajes") {
      initMensajesView();
    }
    if (view === "hys") {
      renderHysAll();
    }
  });
});

// ---------- modales ----------

function openModal(id) { $("#" + id).classList.add("open"); }
function closeModal(id) { $("#" + id).classList.remove("open"); }

$all("[data-close-modal]").forEach((btn) => {
  btn.addEventListener("click", () => closeModal(btn.dataset.closeModal));
});

$all(".modal").forEach((modal) => {
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModal(modal.id);
  });
});

// ------------------------------------------------------------------
// INICIO (dashboard)
// ------------------------------------------------------------------

function renderInicio() {
  const mant = state.machines.map(computeMantEstado);
  const atrasadosMant = mant.filter((m) => m.estado === "ATRASADO").length;
  const proximosMant = mant.filter((m) => m.estado === "PRÓXIMO").length;

  const activas = state.orders.filter((o) => o.estado !== "Entregado").length;
  const atrasadasOt = state.orders.filter((o) => computeOtAtraso(o) && o.estado !== "Entregado").length;

  $("#homeStatMantAtrasados").textContent = atrasadosMant;
  $("#homeStatMantProximos").textContent = proximosMant;
  $("#homeStatOtActivas").textContent = activas;
  $("#homeStatOtAtrasadas").textContent = atrasadasOt;
}

// ------------------------------------------------------------------
// MANTENIMIENTO
// ------------------------------------------------------------------

function computeMantEstado(item) {
  if (!item.ultimaRealizacion || !item.frecuenciaDias) {
    return { estado: "-", proxima: null, dias: null };
  }
  const proxima = addDays(item.ultimaRealizacion, item.frecuenciaDias);
  const dias = daysBetween(todayStr(), proxima);
  let estado = "AL DÍA";
  if (dias < 0) estado = "ATRASADO";
  else if (dias <= 7) estado = "PRÓXIMO";
  return { estado, proxima, dias };
}

function renderMantenimiento() {
  const body = $("#tablaMantBody");
  body.innerHTML = "";
  $("#mantEmptyMsg").style.display = state.machines.length ? "none" : "block";

  const sorted = [...state.machines].sort((a, b) => {
    const ea = computeMantEstado(a).dias ?? 9999;
    const eb = computeMantEstado(b).dias ?? 9999;
    return ea - eb;
  });

  sorted.forEach((item) => {
    const { estado, proxima } = computeMantEstado(item);

    const badgeClass =
      estado === "ATRASADO" ? "badge-atrasado" :
      estado === "PRÓXIMO" ? "badge-proximo" :
      estado === "AL DÍA" ? "badge-aldia" : "badge-neutral";

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(item.maquina || "")}</td>
      <td>${escapeHtml(item.tipo || "")}</td>
      <td>${escapeHtml(item.tarea || "")}</td>
      <td>${item.frecuenciaDias ?? "-"}</td>
      <td>${formatDate(item.ultimaRealizacion)}</td>
      <td>${proxima ? formatDate(proxima) : "-"}</td>
      <td><span class="badge ${badgeClass}">${estado}</span></td>
      <td>${escapeHtml(item.responsable || "")}</td>
      <td>${escapeHtml(item.observaciones || "")}</td>
      <td>
        <button class="btn-icon" title="QR de mantenimiento" data-qr-mant="${item.id}">📱</button>
        <button class="btn-icon" title="Editar" data-edit-mant="${item.id}">✏️</button>
        <button class="btn-icon" title="Eliminar" data-del-mant="${item.id}">🗑️</button>
      </td>
    `;
    body.appendChild(tr);
  });

  $all("[data-qr-mant]").forEach((b) => b.addEventListener("click", () => showMaquinaQr(b.dataset.qrMant)));
  $all("[data-edit-mant]").forEach((b) => b.addEventListener("click", () => editMant(b.dataset.editMant)));
  $all("[data-del-mant]").forEach((b) => b.addEventListener("click", () => deleteMant(b.dataset.delMant)));

  renderInicio();
}

$("#btnNuevoMant").addEventListener("click", () => {
  $("#formMant").reset();
  $("#formMant [name=id]").value = "";
  $("#modalMantTitle").textContent = "Nueva tarea de mantenimiento";
  openModal("modalMant");
});

function editMant(id) {
  const item = state.machines.find((m) => m.id === id);
  if (!item) return;
  const f = $("#formMant");
  f.reset();
  f.id.value = item.id;
  f.maquina.value = item.maquina || "";
  f.tipo.value = item.tipo || "Torno CNC";
  f.tarea.value = item.tarea || "";
  f.frecuenciaDias.value = item.frecuenciaDias || "";
  f.ultimaRealizacion.value = item.ultimaRealizacion || "";
  f.responsable.value = item.responsable || "";
  f.observaciones.value = item.observaciones || "";
  $("#modalMantTitle").textContent = "Editar tarea de mantenimiento";
  openModal("modalMant");
}

async function deleteMant(id) {
  if (!confirm("¿Eliminar esta tarea de mantenimiento?")) return;
  await apiDelete(`${API.machines}?id=${id}`);
  state.machines = state.machines.filter((m) => m.id !== id);
  renderMantenimiento();
  populateActivoAsociado();
}

function showMaquinaQr(id) {
  const item = state.machines.find((m) => m.id === id);
  if (!item) return;
  const { proxima } = computeMantEstado(item);

  $("#maquinaQrTitulo").textContent = item.maquina || "Máquina";
  $("#maquinaQrInfo").textContent =
    `${item.tipo || ""} · Tarea: ${item.tarea || "-"} · Próximo: ${proxima ? formatDate(proxima) : "-"}`;

  const qrBox = $("#maquinaQrCode");
  qrBox.innerHTML = "";
  // Mismo criterio que el QR de OT: texto corto y correctLevel L para evitar
  // "code length overflow" con máquinas/tareas de nombre largo.
  const qrText = `Máquina: ${item.maquina}\nTipo: ${item.tipo}\nTarea: ${item.tarea}\nFrecuencia: ${item.frecuenciaDias} días\nPróximo: ${proxima ? formatDate(proxima) : "-"}`;
  if (window.QRCode) {
    try {
      new QRCode(qrBox, { text: qrText, width: 96, height: 96, typeNumber: 0, correctLevel: QRCode.CorrectLevel.L });
    } catch (err) {
      console.error("No se pudo generar el QR de la máquina:", err);
      qrBox.innerHTML = '<span class="muted" style="font-size:0.75rem;">QR no disponible (texto muy largo)</span>';
    }
  }
  openModal("modalMaquinaQr");
}

$("#formMant").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const data = {
    maquina: f.maquina.value,
    tipo: f.tipo.value,
    tarea: f.tarea.value,
    frecuenciaDias: Number(f.frecuenciaDias.value),
    ultimaRealizacion: f.ultimaRealizacion.value,
    responsable: f.responsable.value,
    observaciones: f.observaciones.value,
  };
  if (f.id.value) {
    const updated = await apiSend(API.machines, "PUT", { ...data, id: f.id.value });
    const idx = state.machines.findIndex((m) => m.id === updated.id);
    state.machines[idx] = updated;
  } else {
    const created = await apiSend(API.machines, "POST", data);
    state.machines.push(created);
  }
  closeModal("modalMant");
  renderMantenimiento();
  populateActivoAsociado();
});

// ------------------------------------------------------------------
// PRODUCCION / ÓRDENES DE TRABAJO
// ------------------------------------------------------------------

function computeOtAtraso(item) {
  if (!item.fechaCompromiso || item.estado === "Entregado") return false;
  return daysBetween(item.fechaCompromiso, todayStr()) > 0;
}

function nextOrderNumber() {
  const nums = state.orders
    .map((o) => parseInt((o.numeroOrden || "").replace(/\D/g, ""), 10))
    .filter((n) => !isNaN(n));
  const next = (nums.length ? Math.max(...nums) : 0) + 1;
  return "OT-" + String(next).padStart(4, "0");
}

function populateActivoAsociado() {
  const options = ['<option value="">Sin asignar</option>']
    .concat(state.machines.map((m) => `<option value="${escapeHtml(m.maquina)}">${escapeHtml(m.maquina)}</option>`))
    .join("");
  ["selActivoAsociadoNueva", "selActivoAsociadoEditar"].forEach((id) => {
    const sel = document.getElementById(id);
    if (!sel) return;
    const current = sel.value;
    sel.innerHTML = options;
    sel.value = current;
  });
}

function renderStatsOT() {
  const activas = state.orders.filter((o) => o.estado !== "Entregado").length;
  const enProceso = state.orders.filter((o) => o.estado === "En proceso").length;
  const atrasadas = state.orders.filter((o) => computeOtAtraso(o)).length;
  const finalizadas = state.orders.filter((o) => o.estado === "Entregado").length;

  $("#statOtActivas").textContent = activas;
  $("#statOtEnProceso").textContent = enProceso;
  $("#statOtAtrasadas").textContent = atrasadas;
  $("#statOtFinalizadas").textContent = finalizadas;
}

function estadoBadgeClass(estado) {
  return "badge-estado-" + slug(estado || "pendiente");
}

function prioridadBadgeClass(prioridad) {
  return "badge-prioridad-" + slug(prioridad || "media");
}

function renderOrdenes() {
  renderStatsOT();

  const search = ($("#otSearch").value || "").toLowerCase().trim();
  const filtroEstado = $("#otFilterEstado").value;
  const filtroPrioridad = $("#otFilterPrioridad").value;

  let list = [...state.orders];

  if (search) {
    list = list.filter((o) =>
      [o.numeroOrden, o.cliente, o.activoAsociado, o.operario, o.titulo]
        .some((v) => (v || "").toLowerCase().includes(search))
    );
  }
  if (filtroEstado) list = list.filter((o) => o.estado === filtroEstado);
  if (filtroPrioridad) list = list.filter((o) => o.prioridad === filtroPrioridad);

  list.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));

  const container = $("#otCardsList");
  container.innerHTML = "";
  $("#ordenesEmptyMsg").style.display = state.orders.length ? "none" : "block";

  list.forEach((item) => {
    const atrasada = computeOtAtraso(item);
    const estadoLabel = atrasada ? "Atrasada" : (item.estado || "Pendiente");
    const estadoClass = atrasada ? "badge-atrasado" : estadoBadgeClass(item.estado);
    const planos = item.planoData ? 1 : 0;
    const remitos = [item.remitoCliente, item.remitoSalida].filter(Boolean).length;

    const card = document.createElement("div");
    card.className = "ot-card";
    card.innerHTML = `
      <div class="ot-card-top">
        <span class="ot-card-id">${escapeHtml(item.numeroOrden || "")}</span>
        <span class="badge ${prioridadBadgeClass(item.prioridad)}">${escapeHtml(item.prioridad || "Media")}</span>
        <span class="badge ${estadoClass}">${escapeHtml(estadoLabel)}</span>
      </div>
      <div class="ot-card-title">${escapeHtml(item.titulo || "")}</div>
      <div class="ot-card-meta">
        <div><b>Cliente:</b> ${escapeHtml(item.cliente || "-")}</div>
        <div><b>Operario:</b> ${escapeHtml(item.operario || "Sin asignar")}</div>
        <div><b>Activo:</b> ${escapeHtml(item.activoAsociado || "Sin asignar")}</div>
        <div><b>Entrega:</b> ${formatDate(item.fechaCompromiso)}</div>
      </div>
      <div class="ot-card-footer">
        <span>Planos: ${planos} · Remitos: ${remitos} · Cant.: ${item.cantidad ?? 1}</span>
        <button class="btn btn-outline" data-ver-ot="${item.id}">Ver detalles</button>
      </div>
    `;
    container.appendChild(card);
  });

  $all("[data-ver-ot]").forEach((b) => b.addEventListener("click", () => verDetalleOt(b.dataset.verOt)));

  renderInicio();
}

["input", "change"].forEach((evt) => {
  $("#otSearch").addEventListener(evt, renderOrdenes);
  $("#otFilterEstado").addEventListener("change", renderOrdenes);
  $("#otFilterPrioridad").addEventListener("change", renderOrdenes);
});

// ---- Nueva OT (formulario inline) ----

function readOrdenForm(f) {
  return {
    cliente: f.cliente.value,
    titulo: f.titulo.value,
    cantidad: Number(f.cantidad.value) || 1,
    fechaCompromiso: f.fechaCompromiso.value,
    ordenCompra: f.ordenCompra.value,
    remitoCliente: f.remitoCliente.value,
    remitoSalida: f.remitoSalida.value,
    operario: f.operario.value,
    requiereValidacion: !!f.requiereValidacion.checked,
    requiereTTA: !!f.requiereTTA.checked,
    requierePlano: !!f.requierePlano.checked,
    activoAsociado: f.activoAsociado.value,
    tipo: f.tipo.value,
    prioridad: f.prioridad.value,
    ubicacion: f.ubicacion.value,
    horasEstimadas: f.horasEstimadas.value ? Number(f.horasEstimadas.value) : null,
  };
}

$("#formOrdenNueva").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const data = readOrdenForm(f);
  data.numeroOrden = nextOrderNumber();
  data.estado = "Pendiente";
  data.fechaInicio = todayStr();
  data.entregaReal = "";
  data.observaciones = "";

  const file = f.planoAdjunto.files[0];
  if (file) {
    data.planoData = await fileToDataUrl(file);
    data.planoNombre = file.name;
  }

  const created = await apiSend(API.orders, "POST", data);
  state.orders.push(created);
  f.reset();
  $("#selActivoAsociadoNueva").value = "";
  renderOrdenes();
});

// ---- Ver detalle / QR / plano ----

let otDetalleActualId = null;

function verDetalleOt(id) {
  const item = state.orders.find((o) => o.id === id);
  if (!item) return;
  otDetalleActualId = id;

  $("#otDetalleTitulo").textContent = `${item.numeroOrden} · ${item.titulo || ""}`;

  const atrasada = computeOtAtraso(item);
  const estadoLabel = atrasada ? "Atrasada" : (item.estado || "Pendiente");
  const estadoClass = atrasada ? "badge-atrasado" : estadoBadgeClass(item.estado);

  const tags = [`<span class="badge ${prioridadBadgeClass(item.prioridad)}">${escapeHtml(item.prioridad || "Media")}</span>`,
    `<span class="badge ${estadoClass}">${escapeHtml(estadoLabel)}</span>`];
  if (item.requiereValidacion) tags.push('<span class="badge badge-neutral">Requiere validación</span>');
  if (item.requiereTTA) tags.push('<span class="badge badge-neutral">Requiere TTA</span>');
  if (item.requierePlano) tags.push('<span class="badge badge-neutral">Requiere plano</span>');
  $("#otDetalleTags").innerHTML = tags.join(" ");

  const rows = [
    ["Cliente", item.cliente], ["Operario / responsable", item.operario || "Sin asignar"],
    ["Activo asociado", item.activoAsociado || "Sin asignar"], ["Tipo", item.tipo],
    ["Cantidad", item.cantidad ?? 1], ["Ubicación / sector", item.ubicacion || "-"],
    ["Fecha inicio", formatDate(item.fechaInicio)], ["Fecha compromiso", formatDate(item.fechaCompromiso)],
    ["Entrega real", item.entregaReal ? formatDate(item.entregaReal) : "-"], ["Horas estimadas", item.horasEstimadas ?? "-"],
    ["Orden de compra", item.ordenCompra || "-"], ["Remito cliente", item.remitoCliente || "-"],
    ["Remito salida", item.remitoSalida || "-"], ["", ""],
  ];

  let gridHtml = rows.map(([label, val]) => label ? `
    <div><div class="label">${escapeHtml(label)}</div><div>${escapeHtml(val)}</div></div>
  ` : "").join("");

  if (item.observaciones) {
    gridHtml += `<div class="full"><div class="label">Observaciones</div><div>${escapeHtml(item.observaciones)}</div></div>`;
  }
  $("#otDetalleGrid").innerHTML = gridHtml;

  if (item.planoData) {
    $("#otDetallePlano").innerHTML = `<a class="plano-link" href="${item.planoData}" download="${escapeHtml(item.planoNombre || "plano")}">📎 Descargar plano adjunto (${escapeHtml(item.planoNombre || "archivo")})</a>`;
  } else {
    $("#otDetallePlano").innerHTML = `<p class="muted">Sin plano adjunto.</p>`;
  }

  const qrBox = $("#otQrCode");
  qrBox.innerHTML = "";
  // Texto corto a propósito: "Trabajo" (título libre) queda afuera porque su
  // longitud variable es la causa más común de overflow en el QR.
  const qrText = `OT ${item.numeroOrden}\nCliente: ${item.cliente}\nEntrega: ${formatDate(item.fechaCompromiso)}`;
  if (window.QRCode) {
    try {
      // correctLevel L (menor redundancia, mayor capacidad) y typeNumber 0 (auto)
      // evitan "code length overflow" cuando cliente/título son largos.
      new QRCode(qrBox, { text: qrText, width: 96, height: 96, typeNumber: 0, correctLevel: QRCode.CorrectLevel.L });
    } catch (err) {
      console.error("No se pudo generar el QR de la OT:", err);
      qrBox.innerHTML = '<span class="muted" style="font-size:0.75rem;">QR no disponible (texto muy largo)</span>';
    }
  }

  openModal("modalOtDetalle");
}

$("#btnEliminarOt").addEventListener("click", async () => {
  if (!otDetalleActualId) return;
  if (!confirm("¿Eliminar esta orden de trabajo?")) return;
  await apiDelete(`${API.orders}?id=${otDetalleActualId}`);
  state.orders = state.orders.filter((o) => o.id !== otDetalleActualId);
  closeModal("modalOtDetalle");
  renderOrdenes();
});

$("#btnEditarOt").addEventListener("click", () => {
  const item = state.orders.find((o) => o.id === otDetalleActualId);
  if (!item) return;
  const f = $("#formOtEditar");
  f.reset();
  f.id.value = item.id;
  f.cliente.value = item.cliente || "";
  f.titulo.value = item.titulo || "";
  f.cantidad.value = item.cantidad ?? 1;
  f.fechaCompromiso.value = item.fechaCompromiso || "";
  f.ordenCompra.value = item.ordenCompra || "";
  f.remitoCliente.value = item.remitoCliente || "";
  f.remitoSalida.value = item.remitoSalida || "";
  f.operario.value = item.operario || "";
  f.requiereValidacion.checked = !!item.requiereValidacion;
  f.requiereTTA.checked = !!item.requiereTTA;
  f.requierePlano.checked = !!item.requierePlano;
  f.activoAsociado.value = item.activoAsociado || "";
  f.tipo.value = item.tipo || "Correctivo";
  f.prioridad.value = item.prioridad || "Media";
  f.ubicacion.value = item.ubicacion || "";
  f.horasEstimadas.value = item.horasEstimadas ?? "";
  f.estado.value = item.estado || "Pendiente";
  f.entregaReal.value = item.entregaReal || "";
  f.observaciones.value = item.observaciones || "";
  closeModal("modalOtDetalle");
  openModal("modalOtEditar");
});

$("#formOtEditar").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const data = readOrdenForm(f);
  data.id = f.id.value;
  data.estado = f.estado.value;
  data.entregaReal = f.entregaReal.value;
  data.observaciones = f.observaciones.value;

  const file = f.planoAdjunto.files[0];
  if (file) {
    data.planoData = await fileToDataUrl(file);
    data.planoNombre = file.name;
  }

  const updated = await apiSend(API.orders, "PUT", data);
  const idx = state.orders.findIndex((o) => o.id === updated.id);
  state.orders[idx] = updated;
  closeModal("modalOtEditar");
  renderOrdenes();
});

// ------------------------------------------------------------------
// MONITOR DE TALLER (pizarra en vivo)
// ------------------------------------------------------------------

let monitorClockInterval = null;
let monitorRefreshInterval = null;

function startMonitorRefresh() {
  stopMonitorRefresh();
  updateMonitorClock();
  monitorClockInterval = setInterval(updateMonitorClock, 1000);
  monitorRefreshInterval = setInterval(renderMonitor, 30000);
}

function stopMonitorRefresh() {
  if (monitorClockInterval) clearInterval(monitorClockInterval);
  if (monitorRefreshInterval) clearInterval(monitorRefreshInterval);
  monitorClockInterval = null;
  monitorRefreshInterval = null;
}

function updateMonitorClock() {
  const el = $("#monitorClock");
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function formatElapsed(isoStart) {
  if (!isoStart) return "-";
  const start = new Date(isoStart).getTime();
  if (isNaN(start)) return "-";
  let diff = Math.max(0, Date.now() - start);
  const days = Math.floor(diff / 86400000);
  diff -= days * 86400000;
  const hours = Math.floor(diff / 3600000);
  diff -= hours * 3600000;
  const mins = Math.floor(diff / 60000);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m`;
}

function formatRemaining(fechaCompromiso) {
  if (!fechaCompromiso) return "-";
  const dias = daysBetween(todayStr(), fechaCompromiso);
  if (dias < 0) return `Atrasada hace ${Math.abs(dias)} día${Math.abs(dias) === 1 ? "" : "s"}`;
  if (dias === 0) return "Vence hoy";
  return `Faltan ${dias} día${dias === 1 ? "" : "s"}`;
}

function renderMonitor() {
  const board = $("#monitorBoard");
  if (!board) return;

  const activas = state.orders
    .filter((o) => o.estado !== "Entregado")
    .sort((a, b) => (a.fechaCompromiso || "9999-99-99").localeCompare(b.fechaCompromiso || "9999-99-99"));

  $("#monitorEmptyMsg").style.display = activas.length ? "none" : "block";
  board.innerHTML = "";

  activas.forEach((item) => {
    const atrasada = computeOtAtraso(item);
    const urgClass = atrasada ? "monitor-urgente" : item.estado === "En proceso" ? "monitor-proceso" : "monitor-normal";

    const card = document.createElement("div");
    card.className = `monitor-card ${urgClass}`;
    card.innerHTML = `
      <div class="monitor-card-top">
        <span class="monitor-card-id">${escapeHtml(item.numeroOrden || "")}</span>
        <span class="badge ${prioridadBadgeClass(item.prioridad)}">${escapeHtml(item.prioridad || "Media")}</span>
      </div>
      <div class="monitor-card-title">${escapeHtml(item.titulo || "")}</div>
      <div class="monitor-card-meta">
        <div><b>Cliente:</b> ${escapeHtml(item.cliente || "-")}</div>
        <div><b>Operario:</b> ${escapeHtml(item.operario || "Sin asignar")}</div>
      </div>
      <div class="monitor-card-times">
        <div><span class="monitor-time-label">En curso</span><span class="monitor-time-value">${formatElapsed(item.createdAt)}</span></div>
        <div><span class="monitor-time-label">Entrega</span><span class="monitor-time-value">${escapeHtml(formatRemaining(item.fechaCompromiso))}</span></div>
      </div>
      <div class="monitor-card-estado">${escapeHtml(item.estado || "Pendiente")}</div>
    `;
    board.appendChild(card);
  });
}

// ------------------------------------------------------------------
// HIGIENE Y SEGURIDAD
// ------------------------------------------------------------------

$all("#hysSubtabs .subtab").forEach((btn) => {
  btn.addEventListener("click", () => {
    const tab = btn.dataset.hysTab;
    $all("#hysSubtabs .subtab").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    $all(".hys-subview").forEach((v) => v.classList.remove("active"));
    $("#hys-" + tab).classList.add("active");
  });
});

function renderHysAll() {
  renderCapacitaciones();
  renderIncidentes();
  renderAccidentes();
  renderProcedimientos();
  renderHysDashboard();
}

// ---- Dashboard / KPI ----

function renderHysDashboard() {
  const hoy = todayStr();
  const anioActual = hoy.slice(0, 4);
  const mesActual = hoy.slice(0, 7);

  // Días sin accidentes
  const fechasAccidentes = state.accidentes.map((a) => a.fecha).filter(Boolean).sort();
  if (fechasAccidentes.length) {
    const ultima = fechasAccidentes[fechasAccidentes.length - 1];
    const dias = daysBetween(ultima, hoy);
    $("#hysStatDiasSinAccidentes").textContent = dias >= 0 ? dias : 0;
    $("#hysStatDiasSinAccidentesNote").textContent = `Desde el último accidente (${formatDate(ultima)})`;
  } else {
    $("#hysStatDiasSinAccidentes").textContent = "-";
    $("#hysStatDiasSinAccidentesNote").textContent = "Sin accidentes registrados";
  }

  const accidentes30 = state.accidentes.filter((a) => a.fecha && daysBetween(a.fecha, hoy) <= 30 && daysBetween(a.fecha, hoy) >= 0).length;
  const incidentes30 = state.incidentes.filter((i) => i.fecha && daysBetween(i.fecha, hoy) <= 30 && daysBetween(i.fecha, hoy) >= 0).length;
  const capacitacionesMes = state.capacitaciones.filter((c) => (c.fecha || "").slice(0, 7) === mesActual).length;
  const accidentesAno = state.accidentes.filter((a) => (a.fecha || "").slice(0, 4) === anioActual).length;
  const diasPerdidos = state.accidentes
    .filter((a) => (a.fecha || "").slice(0, 4) === anioActual)
    .reduce((sum, a) => sum + (Number(a.diasBaja) || 0), 0);
  const incidentesAbiertos = state.incidentes.filter((i) => (i.estado || "Abierto") !== "Cerrado").length;
  const procVencidos = state.procedimientos.filter((p) => {
    if (!p.proximaRevision) return false;
    return daysBetween(hoy, p.proximaRevision) <= 30;
  }).length;

  $("#hysStatAccidentes30").textContent = accidentes30;
  $("#hysStatIncidentes30").textContent = incidentes30;
  $("#hysStatCapacitacionesMes").textContent = capacitacionesMes;
  $("#hysKpiAccidentesAno").textContent = accidentesAno;
  $("#hysKpiDiasPerdidos").textContent = diasPerdidos;
  $("#hysKpiIncidentesAbiertos").textContent = incidentesAbiertos;
  $("#hysKpiProcVencidos").textContent = procVencidos;

  const eventos = [
    ...state.accidentes.map((a) => ({ fecha: a.fecha, tipo: "Accidente", detalle: `${a.empleado || "-"} · ${a.tipoLesion || a.descripcion || ""}`, estado: a.gravedad || a.estado || "-" })),
    ...state.incidentes.map((i) => ({ fecha: i.fecha, tipo: "Incidente", detalle: i.descripcion || "", estado: i.estado || "-" })),
    ...state.capacitaciones.map((c) => ({ fecha: c.fecha, tipo: "Capacitación", detalle: c.tema || "", estado: "Realizada" })),
  ]
    .filter((e) => e.fecha)
    .sort((a, b) => b.fecha.localeCompare(a.fecha))
    .slice(0, 10);

  const body = $("#hysUltimosEventosBody");
  body.innerHTML = "";
  $("#hysUltimosEventosEmpty").style.display = eventos.length ? "none" : "block";
  eventos.forEach((e) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${formatDate(e.fecha)}</td>
      <td>${escapeHtml(e.tipo)}</td>
      <td>${escapeHtml(e.detalle)}</td>
      <td>${escapeHtml(e.estado)}</td>
    `;
    body.appendChild(tr);
  });
}

// ---- Capacitaciones ----

function renderCapacitaciones() {
  const body = $("#tablaCapacitacionesBody");
  body.innerHTML = "";
  $("#capacitacionesEmptyMsg").style.display = state.capacitaciones.length ? "none" : "block";

  const sorted = [...state.capacitaciones].sort((a, b) => (b.fecha || "").localeCompare(a.fecha || ""));
  sorted.forEach((item) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(item.tema || "")}</td>
      <td>${escapeHtml(item.tipo || "")}</td>
      <td>${formatDate(item.fecha)}</td>
      <td>${item.duracionHoras ?? "-"}</td>
      <td>${escapeHtml(item.instructor || "")}</td>
      <td>${item.asistentes ?? "-"}</td>
      <td>${escapeHtml(item.area || "")}</td>
      <td>${item.proximaRenovacion ? formatDate(item.proximaRenovacion) : "-"}</td>
      <td>
        <button class="btn-icon" title="Editar" data-edit-capacitacion="${item.id}">✏️</button>
        <button class="btn-icon" title="Eliminar" data-del-capacitacion="${item.id}">🗑️</button>
      </td>
    `;
    body.appendChild(tr);
  });

  $all("[data-edit-capacitacion]").forEach((b) => b.addEventListener("click", () => editCapacitacion(b.dataset.editCapacitacion)));
  $all("[data-del-capacitacion]").forEach((b) => b.addEventListener("click", () => deleteCapacitacion(b.dataset.delCapacitacion)));
}

$("#btnNuevaCapacitacion").addEventListener("click", () => {
  $("#formCapacitacion").reset();
  $("#formCapacitacion [name=id]").value = "";
  $("#modalCapacitacionTitle").textContent = "Nueva capacitación";
  openModal("modalCapacitacion");
});

function editCapacitacion(id) {
  const item = state.capacitaciones.find((c) => c.id === id);
  if (!item) return;
  const f = $("#formCapacitacion");
  f.reset();
  f.id.value = item.id;
  f.tema.value = item.tema || "";
  f.tipo.value = item.tipo || "Inducción";
  f.fecha.value = item.fecha || "";
  f.duracionHoras.value = item.duracionHoras ?? "";
  f.instructor.value = item.instructor || "";
  f.asistentes.value = item.asistentes ?? "";
  f.area.value = item.area || "";
  f.proximaRenovacion.value = item.proximaRenovacion || "";
  f.observaciones.value = item.observaciones || "";
  $("#modalCapacitacionTitle").textContent = "Editar capacitación";
  openModal("modalCapacitacion");
}

async function deleteCapacitacion(id) {
  if (!confirm("¿Eliminar esta capacitación?")) return;
  await apiDelete(`${API.capacitaciones}?id=${id}`);
  state.capacitaciones = state.capacitaciones.filter((c) => c.id !== id);
  renderCapacitaciones();
  renderHysDashboard();
}

$("#formCapacitacion").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const data = {
    tema: f.tema.value,
    tipo: f.tipo.value,
    fecha: f.fecha.value,
    duracionHoras: f.duracionHoras.value ? Number(f.duracionHoras.value) : null,
    instructor: f.instructor.value,
    asistentes: f.asistentes.value ? Number(f.asistentes.value) : null,
    area: f.area.value,
    proximaRenovacion: f.proximaRenovacion.value,
    observaciones: f.observaciones.value,
  };
  if (f.id.value) {
    const updated = await apiSend(API.capacitaciones, "PUT", { ...data, id: f.id.value });
    const idx = state.capacitaciones.findIndex((c) => c.id === updated.id);
    state.capacitaciones[idx] = updated;
  } else {
    const created = await apiSend(API.capacitaciones, "POST", data);
    state.capacitaciones.push(created);
  }
  closeModal("modalCapacitacion");
  renderCapacitaciones();
  renderHysDashboard();
});

// ---- Incidentes ----

function renderIncidentes() {
  const body = $("#tablaIncidentesBody");
  body.innerHTML = "";
  $("#incidentesEmptyMsg").style.display = state.incidentes.length ? "none" : "block";

  const sorted = [...state.incidentes].sort((a, b) => (b.fecha || "").localeCompare(a.fecha || ""));
  sorted.forEach((item) => {
    const estadoClass = item.estado === "Cerrado" ? "badge-aldia" : item.estado === "En proceso" ? "badge-proximo" : "badge-atrasado";
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${formatDate(item.fecha)}</td>
      <td>${escapeHtml(item.tipo || "")}</td>
      <td>${escapeHtml(item.area || "")}</td>
      <td>${escapeHtml(item.descripcion || "")}</td>
      <td>${escapeHtml(item.severidad || "")}</td>
      <td><span class="badge ${estadoClass}">${escapeHtml(item.estado || "Abierto")}</span></td>
      <td>${escapeHtml(item.reportadoPor || "")}</td>
      <td>
        <button class="btn-icon" title="Editar" data-edit-incidente="${item.id}">✏️</button>
        <button class="btn-icon" title="Eliminar" data-del-incidente="${item.id}">🗑️</button>
      </td>
    `;
    body.appendChild(tr);
  });

  $all("[data-edit-incidente]").forEach((b) => b.addEventListener("click", () => editIncidente(b.dataset.editIncidente)));
  $all("[data-del-incidente]").forEach((b) => b.addEventListener("click", () => deleteIncidente(b.dataset.delIncidente)));
}

$("#btnNuevoIncidente").addEventListener("click", () => {
  $("#formIncidente").reset();
  $("#formIncidente [name=id]").value = "";
  $("#modalIncidenteTitle").textContent = "Nuevo incidente";
  openModal("modalIncidente");
});

function editIncidente(id) {
  const item = state.incidentes.find((i) => i.id === id);
  if (!item) return;
  const f = $("#formIncidente");
  f.reset();
  f.id.value = item.id;
  f.fecha.value = item.fecha || "";
  f.tipo.value = item.tipo || "Casi accidente";
  f.area.value = item.area || "";
  f.descripcion.value = item.descripcion || "";
  f.reportadoPor.value = item.reportadoPor || "";
  f.severidad.value = item.severidad || "Media";
  f.accionCorrectiva.value = item.accionCorrectiva || "";
  f.estado.value = item.estado || "Abierto";
  $("#modalIncidenteTitle").textContent = "Editar incidente";
  openModal("modalIncidente");
}

async function deleteIncidente(id) {
  if (!confirm("¿Eliminar este incidente?")) return;
  await apiDelete(`${API.incidentes}?id=${id}`);
  state.incidentes = state.incidentes.filter((i) => i.id !== id);
  renderIncidentes();
  renderHysDashboard();
}

$("#formIncidente").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const data = {
    fecha: f.fecha.value,
    tipo: f.tipo.value,
    area: f.area.value,
    descripcion: f.descripcion.value,
    reportadoPor: f.reportadoPor.value,
    severidad: f.severidad.value,
    accionCorrectiva: f.accionCorrectiva.value,
    estado: f.estado.value,
  };
  if (f.id.value) {
    const updated = await apiSend(API.incidentes, "PUT", { ...data, id: f.id.value });
    const idx = state.incidentes.findIndex((i) => i.id === updated.id);
    state.incidentes[idx] = updated;
  } else {
    const created = await apiSend(API.incidentes, "POST", data);
    state.incidentes.push(created);
  }
  closeModal("modalIncidente");
  renderIncidentes();
  renderHysDashboard();
});

// ---- Accidentes ----

function renderAccidentes() {
  const body = $("#tablaAccidentesBody");
  body.innerHTML = "";
  $("#accidentesEmptyMsg").style.display = state.accidentes.length ? "none" : "block";

  const sorted = [...state.accidentes].sort((a, b) => (b.fecha || "").localeCompare(a.fecha || ""));
  sorted.forEach((item) => {
    const estadoClass = item.estado === "Cerrado" ? "badge-aldia" : item.estado === "En proceso" ? "badge-proximo" : "badge-atrasado";
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${formatDate(item.fecha)}</td>
      <td>${escapeHtml(item.empleado || "")}</td>
      <td>${escapeHtml(item.area || "")}</td>
      <td>${escapeHtml(item.tipoLesion || "")}</td>
      <td>${escapeHtml(item.gravedad || "")}</td>
      <td>${item.diasBaja ?? 0}</td>
      <td><span class="badge ${estadoClass}">${escapeHtml(item.estado || "Abierto")}</span></td>
      <td>
        <button class="btn-icon" title="Editar" data-edit-accidente="${item.id}">✏️</button>
        <button class="btn-icon" title="Eliminar" data-del-accidente="${item.id}">🗑️</button>
      </td>
    `;
    body.appendChild(tr);
  });

  $all("[data-edit-accidente]").forEach((b) => b.addEventListener("click", () => editAccidente(b.dataset.editAccidente)));
  $all("[data-del-accidente]").forEach((b) => b.addEventListener("click", () => deleteAccidente(b.dataset.delAccidente)));
}

$("#btnNuevoAccidente").addEventListener("click", () => {
  $("#formAccidente").reset();
  $("#formAccidente [name=id]").value = "";
  $("#modalAccidenteTitle").textContent = "Nuevo accidente";
  openModal("modalAccidente");
});

function editAccidente(id) {
  const item = state.accidentes.find((a) => a.id === id);
  if (!item) return;
  const f = $("#formAccidente");
  f.reset();
  f.id.value = item.id;
  f.fecha.value = item.fecha || "";
  f.empleado.value = item.empleado || "";
  f.area.value = item.area || "";
  f.tipoLesion.value = item.tipoLesion || "";
  f.parteCuerpo.value = item.parteCuerpo || "";
  f.gravedad.value = item.gravedad || "Leve (sin baja)";
  f.diasBaja.value = item.diasBaja ?? 0;
  f.estado.value = item.estado || "Abierto";
  f.descripcion.value = item.descripcion || "";
  f.causa.value = item.causa || "";
  f.accionCorrectiva.value = item.accionCorrectiva || "";
  $("#modalAccidenteTitle").textContent = "Editar accidente";
  openModal("modalAccidente");
}

async function deleteAccidente(id) {
  if (!confirm("¿Eliminar este accidente?")) return;
  await apiDelete(`${API.accidentes}?id=${id}`);
  state.accidentes = state.accidentes.filter((a) => a.id !== id);
  renderAccidentes();
  renderHysDashboard();
}

$("#formAccidente").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const data = {
    fecha: f.fecha.value,
    empleado: f.empleado.value,
    area: f.area.value,
    tipoLesion: f.tipoLesion.value,
    parteCuerpo: f.parteCuerpo.value,
    gravedad: f.gravedad.value,
    diasBaja: Number(f.diasBaja.value) || 0,
    estado: f.estado.value,
    descripcion: f.descripcion.value,
    causa: f.causa.value,
    accionCorrectiva: f.accionCorrectiva.value,
  };
  if (f.id.value) {
    const updated = await apiSend(API.accidentes, "PUT", { ...data, id: f.id.value });
    const idx = state.accidentes.findIndex((a) => a.id === updated.id);
    state.accidentes[idx] = updated;
  } else {
    const created = await apiSend(API.accidentes, "POST", data);
    state.accidentes.push(created);
  }
  closeModal("modalAccidente");
  renderAccidentes();
  renderHysDashboard();
});

// ---- Procedimientos ----

function renderProcedimientos() {
  const body = $("#tablaProcedimientosBody");
  body.innerHTML = "";
  $("#procedimientosEmptyMsg").style.display = state.procedimientos.length ? "none" : "block";

  const sorted = [...state.procedimientos].sort((a, b) => (a.codigo || "").localeCompare(b.codigo || ""));
  sorted.forEach((item) => {
    const estadoClass = item.estado === "Vigente" ? "badge-aldia" : item.estado === "En revisión" ? "badge-proximo" : "badge-neutral";
    const archivo = item.archivoData
      ? `<a href="${item.archivoData}" download="${escapeHtml(item.archivoNombre || "procedimiento")}">📎 Ver</a>`
      : "-";
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(item.codigo || "")}</td>
      <td>${escapeHtml(item.nombre || "")}</td>
      <td>${escapeHtml(item.area || "")}</td>
      <td>${escapeHtml(item.version || "")}</td>
      <td>${item.fechaVigencia ? formatDate(item.fechaVigencia) : "-"}</td>
      <td>${item.proximaRevision ? formatDate(item.proximaRevision) : "-"}</td>
      <td><span class="badge ${estadoClass}">${escapeHtml(item.estado || "Vigente")}</span></td>
      <td>${archivo}</td>
      <td>
        <button class="btn-icon" title="Editar" data-edit-procedimiento="${item.id}">✏️</button>
        <button class="btn-icon" title="Eliminar" data-del-procedimiento="${item.id}">🗑️</button>
      </td>
    `;
    body.appendChild(tr);
  });

  $all("[data-edit-procedimiento]").forEach((b) => b.addEventListener("click", () => editProcedimiento(b.dataset.editProcedimiento)));
  $all("[data-del-procedimiento]").forEach((b) => b.addEventListener("click", () => deleteProcedimiento(b.dataset.delProcedimiento)));
}

$("#btnNuevoProcedimiento").addEventListener("click", () => {
  $("#formProcedimiento").reset();
  $("#formProcedimiento [name=id]").value = "";
  $("#modalProcedimientoTitle").textContent = "Nuevo procedimiento";
  openModal("modalProcedimiento");
});

function editProcedimiento(id) {
  const item = state.procedimientos.find((p) => p.id === id);
  if (!item) return;
  const f = $("#formProcedimiento");
  f.reset();
  f.id.value = item.id;
  f.codigo.value = item.codigo || "";
  f.nombre.value = item.nombre || "";
  f.area.value = item.area || "";
  f.version.value = item.version || "";
  f.fechaVigencia.value = item.fechaVigencia || "";
  f.proximaRevision.value = item.proximaRevision || "";
  f.responsable.value = item.responsable || "";
  f.estado.value = item.estado || "Vigente";
  $("#modalProcedimientoTitle").textContent = "Editar procedimiento";
  openModal("modalProcedimiento");
}

async function deleteProcedimiento(id) {
  if (!confirm("¿Eliminar este procedimiento?")) return;
  await apiDelete(`${API.procedimientos}?id=${id}`);
  state.procedimientos = state.procedimientos.filter((p) => p.id !== id);
  renderProcedimientos();
  renderHysDashboard();
}

$("#formProcedimiento").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const data = {
    codigo: f.codigo.value,
    nombre: f.nombre.value,
    area: f.area.value,
    version: f.version.value,
    fechaVigencia: f.fechaVigencia.value,
    proximaRevision: f.proximaRevision.value,
    responsable: f.responsable.value,
    estado: f.estado.value,
  };

  const file = f.archivoAdjunto.files[0];
  if (file) {
    data.archivoData = await fileToDataUrl(file);
    data.archivoNombre = file.name;
  }

  if (f.id.value) {
    const updated = await apiSend(API.procedimientos, "PUT", { ...data, id: f.id.value });
    const idx = state.procedimientos.findIndex((p) => p.id === updated.id);
    state.procedimientos[idx] = updated;
  } else {
    const created = await apiSend(API.procedimientos, "POST", data);
    state.procedimientos.push(created);
  }
  closeModal("modalProcedimiento");
  renderProcedimientos();
  renderHysDashboard();
});

// ------------------------------------------------------------------
// MENSAJES INTERNO (requiere login de Gerencia o Mantenimiento)
// ------------------------------------------------------------------

const MENSAJES_SESSION_KEY = "tallerMensajesSesion";

function getMensajesSession() {
  try {
    const raw = localStorage.getItem(MENSAJES_SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (err) {
    return null;
  }
}

function setMensajesSession(rol) {
  localStorage.setItem(MENSAJES_SESSION_KEY, JSON.stringify({ rol, ts: Date.now() }));
}

function clearMensajesSession() {
  localStorage.removeItem(MENSAJES_SESSION_KEY);
}

function initMensajesView() {
  const session = getMensajesSession();
  if (session && session.rol) {
    showMensajesBoard(session.rol);
  } else {
    showMensajesLogin();
  }
}

function showMensajesLogin() {
  $("#mensajesLogin").style.display = "block";
  $("#mensajesBoard").style.display = "none";
  $("#mensajesLoginError").style.display = "none";
}

function showMensajesBoard(rol) {
  $("#mensajesLogin").style.display = "none";
  $("#mensajesBoard").style.display = "block";
  $("#mensajesRolActual").textContent = rol;
  loadMessages();
}

$("#formMensajesLogin").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const usuario = f.usuario.value;
  const password = f.password.value;
  const errBox = $("#mensajesLoginError");
  errBox.style.display = "none";
  try {
    const res = await fetch(API.auth, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usuario, password }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      errBox.textContent = data.error || "Contraseña incorrecta.";
      errBox.style.display = "block";
      return;
    }
    setMensajesSession(data.rol);
    f.reset();
    showMensajesBoard(data.rol);
  } catch (err) {
    errBox.textContent = "No se pudo conectar. Probá de nuevo.";
    errBox.style.display = "block";
  }
});

$("#btnMensajesLogout").addEventListener("click", () => {
  clearMensajesSession();
  showMensajesLogin();
});

async function loadMessages() {
  try {
    state.messages = await apiGet(API.messages);
    renderMensajes();
  } catch (err) {
    console.error(err);
  }
}

function formatDateTime(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "-";
  return d.toLocaleString("es-AR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

function renderMensajes() {
  const list = $("#mensajesList");
  if (!list) return;
  list.innerHTML = "";
  const sorted = [...state.messages].sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
  $("#mensajesEmptyMsg").style.display = sorted.length ? "none" : "block";

  sorted.forEach((m) => {
    const badgeClass = m.autor === "Gerencia" ? "msg-badge-gerencia" : "msg-badge-mantenimiento";
    const div = document.createElement("div");
    div.className = "msg-item";
    div.innerHTML = `
      <div class="msg-item-header">
        <span class="badge ${badgeClass}">${escapeHtml(m.autor || "-")}</span>
        <span class="msg-date">${formatDateTime(m.createdAt)}</span>
      </div>
      <div class="msg-text">${escapeHtml(m.texto || "")}</div>
    `;
    list.appendChild(div);
  });
}

$("#formMensajeNuevo").addEventListener("submit", async (e) => {
  e.preventDefault();
  const session = getMensajesSession();
  if (!session) {
    showMensajesLogin();
    return;
  }
  const f = e.target;
  const texto = f.texto.value.trim();
  if (!texto) return;
  const created = await apiSend(API.messages, "POST", { autor: session.rol, texto });
  state.messages.push(created);
  f.reset();
  renderMensajes();
});

// ------------------------------------------------------------------
// PRESUPUESTOS
// ------------------------------------------------------------------

function calcQuote(f) {
  const material = Number(f.costoMaterial.value) || 0;
  const hConv = Number(f.horasConvencional.value) || 0;
  const hCNC = Number(f.horasCNC.value) || 0;
  const hSold = Number(f.horasSoldadura.value) || 0;
  const margen = Number(f.margen.value) || 0;

  const rates = state.settings || {};
  const subtotal =
    material +
    hConv * (rates.rateConvencional || 0) +
    hCNC * (rates.rateCNC || 0) +
    hSold * (rates.rateSoldadura || 0);
  const total = subtotal * (1 + margen / 100);
  return { subtotal, total };
}

function updateQuotePreview() {
  const f = $("#formPresupuesto");
  const { subtotal, total } = calcQuote(f);
  $("#quotePreview").innerHTML = `Subtotal: ${money(subtotal)} &nbsp;|&nbsp; Total con margen: <strong>${money(total)}</strong>`;
}

["costoMaterial", "horasConvencional", "horasCNC", "horasSoldadura", "margen"].forEach((name) => {
  document.addEventListener("input", (e) => {
    if (e.target && e.target.name === name && e.target.closest("#formPresupuesto")) {
      updateQuotePreview();
    }
  });
});

function renderPresupuestos() {
  const body = $("#tablaPresupuestosBody");
  body.innerHTML = "";
  $("#presEmptyMsg").style.display = state.quotes.length ? "none" : "block";

  const sorted = [...state.quotes].sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));

  sorted.forEach((item) => {
    const { total } = calcQuote({
      costoMaterial: { value: item.costoMaterial },
      horasConvencional: { value: item.horasConvencional },
      horasCNC: { value: item.horasCNC },
      horasSoldadura: { value: item.horasSoldadura },
      margen: { value: item.margen },
    });

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(item.numero || "")}</td>
      <td>${escapeHtml(item.cliente || "")}</td>
      <td>${escapeHtml(item.descripcion || "")}</td>
      <td>${money(item.costoMaterial)}</td>
      <td>${item.horasConvencional || 0}</td>
      <td>${item.horasCNC || 0}</td>
      <td>${item.horasSoldadura || 0}</td>
      <td>${item.margen || 0}%</td>
      <td><strong>${money(total)}</strong></td>
      <td>${item.createdAt ? formatDate(item.createdAt.slice(0, 10)) : "-"}</td>
      <td><button class="btn-icon" title="Eliminar" data-del-pres="${item.id}">🗑️</button></td>
    `;
    body.appendChild(tr);
  });

  $all("[data-del-pres]").forEach((b) => b.addEventListener("click", () => deletePresupuesto(b.dataset.delPres)));
}

async function deletePresupuesto(id) {
  if (!confirm("¿Eliminar este presupuesto?")) return;
  await apiDelete(`${API.quotes}?id=${id}`);
  state.quotes = state.quotes.filter((q) => q.id !== id);
  renderPresupuestos();
}

$("#btnNuevoPresupuesto").addEventListener("click", () => {
  $("#formPresupuesto").reset();
  $("#presMargenInput").value = state.settings ? state.settings.defaultMargin : 30;
  updateQuotePreview();
  openModal("modalPresupuesto");
});

$("#formPresupuesto").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const data = {
    numero: f.numero.value,
    cliente: f.cliente.value,
    descripcion: f.descripcion.value,
    costoMaterial: Number(f.costoMaterial.value) || 0,
    horasConvencional: Number(f.horasConvencional.value) || 0,
    horasCNC: Number(f.horasCNC.value) || 0,
    horasSoldadura: Number(f.horasSoldadura.value) || 0,
    margen: Number(f.margen.value) || 0,
  };
  const created = await apiSend(API.quotes, "POST", data);
  state.quotes.push(created);
  closeModal("modalPresupuesto");
  renderPresupuestos();
});

// ------------------------------------------------------------------
// CONFIGURACION
// ------------------------------------------------------------------

function fillConfigForm() {
  const s = state.settings || {};
  $("#cfgEmpresa").value = s.empresa || "";
  $("#cfgRateConv").value = s.rateConvencional ?? 0;
  $("#cfgRateCNC").value = s.rateCNC ?? 0;
  $("#cfgRateSold").value = s.rateSoldadura ?? 0;
  $("#cfgMargin").value = s.defaultMargin ?? 0;
  const nombre = s.empresa || "Sistema de Taller";
  $("#empresaNombreSidebar").textContent = nombre;
  $("#empresaNombreTop").textContent = nombre;
}

$("#formConfig").addEventListener("submit", async (e) => {
  e.preventDefault();
  const data = {
    empresa: $("#cfgEmpresa").value,
    rateConvencional: Number($("#cfgRateConv").value) || 0,
    rateCNC: Number($("#cfgRateCNC").value) || 0,
    rateSoldadura: Number($("#cfgRateSold").value) || 0,
    defaultMargin: Number($("#cfgMargin").value) || 0,
  };
  state.settings = await apiSend(API.settings, "PUT", data);
  fillConfigForm();
  const msg = $("#cfgSavedMsg");
  msg.textContent = "Guardado ✓";
  setTimeout(() => (msg.textContent = ""), 2500);
});

$("#formCambiarPassword").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const usuario = f.usuario.value;
  const passwordActual = f.passwordActual.value;
  const passwordNueva = f.passwordNueva.value;
  const msg = $("#cfgPassMsg");
  msg.style.color = "";
  try {
    const res = await fetch(API.auth, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usuario, passwordActual, passwordNueva }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      msg.textContent = data.error || "No se pudo cambiar la contraseña.";
      msg.style.color = "#8a2c1f";
      return;
    }
    msg.textContent = "Contraseña actualizada ✓";
    f.reset();
    setTimeout(() => (msg.textContent = ""), 3000);
  } catch (err) {
    msg.textContent = "Error de conexión.";
    msg.style.color = "#8a2c1f";
  }
});

// ------------------------------------------------------------------
// CARGA INICIAL
// ------------------------------------------------------------------

async function loadAll() {
  try {
    const [machines, orders, quotes, settings, capacitaciones, incidentes, accidentes, procedimientos] = await Promise.all([
      apiGet(API.machines),
      apiGet(API.orders),
      apiGet(API.quotes),
      apiGet(API.settings),
      apiGet(API.capacitaciones),
      apiGet(API.incidentes),
      apiGet(API.accidentes),
      apiGet(API.procedimientos),
    ]);
    state.machines = machines;
    state.orders = orders;
    state.quotes = quotes;
    state.settings = settings;
    state.capacitaciones = capacitaciones;
    state.incidentes = incidentes;
    state.accidentes = accidentes;
    state.procedimientos = procedimientos;

    fillConfigForm();
    populateActivoAsociado();
    renderMantenimiento();
    renderOrdenes();
    renderPresupuestos();
    renderHysAll();
    renderInicio();
  } catch (err) {
    console.error(err);
    alert("No se pudieron cargar los datos. Revisá la conexión y recargá la página.");
  }
}

loadAll();
